<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1740203613468'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\dvs\p4\build\sw\rel\gpgpu\toolkit\r12.8\built\x86_64_win32_release\viper\com.nvidia.viper.product\products\com.nvidia.viper.application.product\win32\win32\x86_64\libnvvp'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\dvs\p4\build\sw\rel\gpgpu\toolkit\r12.8\built\x86_64_win32_release\viper\com.nvidia.viper.product\products\com.nvidia.viper.application.product\win32\win32\x86_64\libnvvp'/>
  </properties>
</profile>
